<section class="section-search-domain">
	<div class="container">
		<div class="search-domain-box">
			<div class="title-search-domain anitext">
				<?= titlesearchdomain?>
			</div>
			<div class="form-search-domain flex-row">
				<input type="text" id="input-seacrh-domain" placeholder="<?=placeholder?>" class="search-auto wow fadeInLeft" data-wow-duration="0.4s"data-wow-delay="0.4s">
				<button class=" wow fadeInRight" data-wow-duration="0.4s"data-wow-delay="0.4s">
					<i class="fas fa-check"></i><?=checkdomain?>
					<div id="spinner3"></div>
				</button>
			</div>
			<div class="option_checkbox option_checkbox_home flex-row">
                <div class="item_checkbox  wow fadeInRight" data-wow-duration="0.4s"data-wow-delay="0.4s">
                    <input type="checkbox" value=".com" checked="checked" id="com">
                    <label for="com">.com</label>
                </div>
                <div class="item_checkbox  wow fadeInRight" data-wow-duration="0.4s"data-wow-delay="0.5s">
                    <input type="checkbox" value=".vn" checked="checked" id="vn">
                    <label for="vn">.vn</label>
                </div>
                <div class="item_checkbox  wow fadeInRight" data-wow-duration="0.4s"data-wow-delay="0.6s">
                    <input type="checkbox" value=".net" checked="checked" id="net">
                    <label for="net">.net</label>
                </div>
                <div class="item_checkbox  wow fadeInRight" data-wow-duration="0.4s"data-wow-delay="0.7s">
                    <input type="checkbox" id="info" value=".info" name="" checked="checked">
                    <label for="info">.info</label>
                </div>
                <div class="item_checkbox  wow fadeInRight" data-wow-duration="0.4s"data-wow-delay="0.8s">
                    <input type="checkbox" value=".com.vn" checked="checked" id="comvn">
                    <label for="comvn">.com.vn</label>
                </div>
            </div>
            <div class="box-nhanthongtin">
			</div>
		</div>
	</div>
	
</section>