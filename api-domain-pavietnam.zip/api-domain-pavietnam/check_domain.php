<?php 
include "ajax_config.php";
include '../whmcs/api_config.php';

if(!empty($_GET['d']))
{
	include 'api_config.php';

	if($_GET['ch_list']){
		$list=base64_decode($_GET['ch_list']);
		$list_d=(explode(",",$list));
	}
	$domainfirst=trim($_GET['d']).$list_d[0];
	$html_result='';

	$html_result.='<div class="result-item flex-row">';
	$domain 	= trim($_GET['d']).$list_d[0];
	$result 	= file_get_contents(API_URL."?cmd=check_whois&apikey=".API_KEY."&username=".USERNAME."&domain=".$domain);
	if($result == '0')
	{
		$html_result.="<p><a href='http://$domain' target='_blank'>".trim($_GET['d'])."<strong>".$list_d[0]."</strong></a></p> <span class='registered' >đã đuợc đăng ký</span>";
	}
	elseif($result == '1')
	{
		$html_result.="<p>".trim($_GET['d'])."<strong>".$list_d[0]."</strong></p> <span>chưa đăng ký</span>";
	}
	else
	{
		$html_result.="<span style='color:#F00'>$result</span>";
	}
	$html_result.='</div>';
	$html_result.='';
}
?>

<script type="text/javascript">
	$(document).ready(function () {
		<?php if(count($list_d)>1){ for ($i=1; $i < count($list_d); $i++) {  ?>
			loadcheck_whois('<?= $_GET['d'] ?>','<?= $list_d[$i] ?>');
		<?php } } ?>
	})
</script>
<?php echo $html_result; ?>