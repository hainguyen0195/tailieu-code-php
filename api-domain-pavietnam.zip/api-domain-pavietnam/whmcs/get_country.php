<?php
	// LẤY DANH SÁCH QUốC GIA
	include 'api_config.php';
	$struct = array(
			'cmd' => 'get_country',//Lệnh lấy danh sách Quốc gia
	);
	
	//Mã hoá url trước khi gọi link thực thi
	$param = '';
	foreach($struct as $k=>$v) $param .= $k.'='.urlencode($v).'&';
	
	$result = file_get_contents(API_URL."?$param");//Gọi link thực thi
	$result = json_decode($result);
	//Xem toàn bộ thông tin trả về
	echo "<pre>".print_r($result,true)."</pre>";
?>