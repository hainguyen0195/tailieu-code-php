<?php
	/*
		ĐỊNH NGHĨA CÁC THÔNG TIN TRUY CẬP API
		Chú ý: 
			- Truy cập vào https://daily.pavietnam.vn/loaddata.php?param=api để lấy API KEY
			- Link API test: https://daily.pavietnam.vn/interface_test.php
			- Link API đăng ký thật: https://daily.pavietnam.vn/interface.php
	*/
	define('USERNAME','dahadumedia');//Username đại lý
	define('API_KEY','8bc795ead81a93b5f5efaa8c5553a6bc');//API KEY
	define('API_URL','https://daily.pavietnam.vn/interface_test.php');//Link API (Mặc định đang là link API test)
	
?>