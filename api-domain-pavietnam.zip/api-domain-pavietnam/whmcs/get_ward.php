<?php
	// LẤY DANH SÁCH PHƯỜNG XÃ THEO QUẬN HUYỆN
	include 'api_config.php';
	$struct = array(
			'cmd' => 'get_ward',//Lệnh lấy danh sách phường xã theo quận huyện
			'district_id' => 760, //ID quận huyện
	);
	
	//Mã hoá url trước khi gọi link thực thi
	$param = '';
	foreach($struct as $k=>$v) $param .= $k.'='.urlencode($v).'&';

	$result = file_get_contents(API_URL."?$param");//Gọi link thực thi
	$result = json_decode($result);
	//Xem toàn bộ thông tin trả về
	echo "<pre>".print_r($result,true)."</pre>";
?>