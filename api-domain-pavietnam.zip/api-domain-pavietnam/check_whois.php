<?php 
	include "ajax_config.php";
	include '../whmcs/api_config.php';

	if(!empty($_GET['d']))
	{
		include 'api_config.php';

		
		$html_result='';
			$html_result.='<div class="result-item flex-row">';
			$domain 	= trim($_GET['d']).$_GET['ch'];
			$result 	= file_get_contents(API_URL."?cmd=check_whois&apikey=".API_KEY."&username=".USERNAME."&domain=".$domain);
			if($result == '0')
			{
				$html_result.="<p><a href='http://$domain' target='_blank'>".trim($_GET['d'])."<strong>".$_GET['ch']."</strong></a></p> <span class='registered' >đã đuợc đăng ký</span>";
			}
			elseif($result == '1')
			{
				$html_result.="<p>".trim($_GET['d'])."<strong>".$_GET['ch']."</strong></p> <span>chưa đăng ký</span>";
			}
			else
			{
				$html_result.="<span style='color:#F00'>$result</span>";
			}
			$html_result.='</div>';
		$html_result.='';
		echo $html_result;
	}

 ?>
