function ajax_load_check_domain(list, domain) {
    $('.box-nhanthongtin').html('');
    if (!$('.form-search-domain #spinner3').hasClass('active')) {
        $('.form-search-domain #spinner3').addClass('active');
        $('.form-search-domain button').addClass('trans');
    }

    $.ajax({
        url: "ajax/check_domain.php",
        method: 'get',
        data: {
            d: domain,
            ch_list: list
        },
        success: function(result) {
            $('.box-nhanthongtin').html(result);
            if ($('.form-search-domain #spinner3').hasClass('active')) {
                $('.form-search-domain button').removeClass('trans');
                $('.form-search-domain #spinner3').removeClass('active');
            }
        }
    })
};

/* Ready */
$(document).ready(function () {
    $('body').on('keyup', '#input-seacrh-domain', function(e) {
        e.preventDefault();
        if (e.key === 'Enter' || e.keyCode === 13) {
            var val = $(this).val();
            if (val == '') {
                alert('Vui lòng nhập tên miền');
                return
            }
            $('.lc__load').addClass('active')
            ch_list = Array();
            $(".option_checkbox_home input:checkbox[type=checkbox]:checked").each(function() {
                ch_list.push($(this).val())
            });
            ch_list = btoa(ch_list);

            ajax_load_check_domain(ch_list, val);
        }
    });
    $('.form-search-domain button').click(function(e) {
        e.preventDefault();
        var val = $(this).prev('input').val();
        if (val == '') {
            alert('Vui lòng nhập tên miền');
            return
        }
        $('.lc__load').addClass('active')
        ch_list = Array();
        $(".option_checkbox_home input:checkbox[type=checkbox]:checked").each(function() {
            ch_list.push($(this).val())
        });
        ch_list = btoa(ch_list);
        ajax_load_check_domain(ch_list, val)
    })
}