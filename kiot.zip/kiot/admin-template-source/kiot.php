<?php
if (!defined('SOURCES')) die("Error");
ini_set('max_execution_time', 300000);

include_once LIBRARIES . "kiot.php";
$kiot = new kiot($d);

$act = (isset($_REQUEST['act'])) ? addslashes($_REQUEST['act']) : "";
$kiot->login();

switch ($act) {
	case "productsync":
		$template = "kiot/productsync";
		break;

	case 'sync':
		sync();
		break;

	default;
		$template = "index";
}

function sync()
{
	global $d, $kiot;

	
	$result = array();
	$result['add'] = 0;
	$result['update'] = 0;
	$result['push'] = 0;
	$type = $_GET['type'];
	$kind = $_GET['kind'];

	if ($kind == 1) {
		// Đồng bộ từ Website lên Kiot Việt
		$data = array();
		foreach ($kiot->getAllProduct()->data as $k => $v) {
			$data[] = $v->code;
		}
		$d->query("SELECT * FROM table_product WHERE type='$type' ORDER BY stt,id DESC");
		foreach ($d->result_array() as $k => $v) {
			if (!in_array($v['masp'], $data)) {
				$kiot->addProductByApi($v);
				$result['push']++;
			}
		}
	} else if ($kind == 2) {
		// Đồng bộ từ Kiot Việt về Website

		$product = $kiot->getAllProduct()->data;
		
		if (count($product)) {
			$data = array();
			foreach ($product as $k => $v) {
				$data[$v->code] = $v;
			}
			foreach ($data as $k => $v) {
				if ($kiot->checkProductIssetWeb($v, $type)) {
					$result['add']++;
				} else {
					$result['update']++;
				}
			}
		}
	} else if ($kind == 3) {
		// Đồng bộ nhóm hàng
		$nhomhang = $kiot->getAllCategory()->data;
		if (count($nhomhang)) {
			$data = array();
			foreach ($nhomhang as $k => $v) {
				$data[$v->categoryId] = $v;
			}
			foreach ($data as $k => $v) {
				if ($kiot->checkCategoryIssetWeb($v)) {
					$result['add']++;
				} else {
					$result['update']++;
				}
			}
		}
	}
	echo json_encode($result);
	die;
}
