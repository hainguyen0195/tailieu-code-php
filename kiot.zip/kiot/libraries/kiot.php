<?php
ini_set('max_execution_time', 300000);
class kiot
{
	private $db;
	private $func;
	private $session;
	private $kiotapi_link = "https://public.kiotapi.com";
	private $client = "a0274137-12bc-41aa-b8ef-a5fa881db7ef";
	private $secret = "D918DDF107A8DADB7EAEDF95F84F21DD2566F12E";
	private $name = "songngocsgv1";

	function __construct($d)
	{
		$this->db = $d;
		$this->check_login();
		$this->func = $func;
	}

	function getProductWithPage($url, $offset)
	{
		$url .= "&currentitem=" . $offset;
		$ar = $this->init($url, null, "GET");
		return $ar->data;
	}

	function getAllCategory()
	{
		$ar = array();
		$num = 100;
		$link = "/categories?hierachicalData=true&includeAll=true&orderBy=Name&orderDirection=Asc&Includes=Children&pageSize=$num";
		$ar = $this->init($link, null, "GET");
		$total = $ar->total;
		$page = ceil($total / $num);

		if ($page > 1) {
			for ($i = 1; $i < $page; $i++) {
				foreach ($this->getProductWithPage($link, ($num * $i + 1))  as $k2 => $v2) {
					$ar->data{
						count($ar->data)} = $v2;
				}
			}
		}
		return ($ar);
	}

	function getAllProduct()
	{
		$ar = array();
		$num = 100;
		$link = "/products?includePricebook=true&includeInventory=true&pageSize=$num";
		$ar = $this->init($link, null, "GET");
		$total = $ar->total;
		$page = ceil($total / $num);

		if ($page > 1) {
			for ($i = 1; $i < $page; $i++) {
				foreach ($this->getProductWithPage($link, ($num * $i + 1))  as $k2 => $v2) {
					$ar->data{
						count($ar->data)} = $v2;
				}
			}
		}
		return ($ar);
	}

	function addProductByApi($row)
	{
		/* Gán dữ liệu đồng bộ */
		$arr = array();
		$arr['categoryId'] = $row['id_category'];
		$arr['code'] = $row['masp'];
		$arr['name'] = $row['tenvi'];
		$arr['basePrice'] = $row['gia'];
		$arr['allowsSale'] = 1;
		$arr['conversionValue'] = 0;
		$arr['type'] = 2;
		if ($row['hienthi']) $arr['isActive'] = true;
		else $arr['isActive'] = false;

		/* Gán thuộc tính dữ liệu đồng bộ */
		$arr['inventories'] = array(
			"branchId" => $row['id_branch'],
			"branchName" => $row['ten_branch'],
			"onHand" => $row['soluong']
		);

		/* Đồng bộ dữ liệu */
		$rs = $this->init("/products", $arr, "POST");
	}

	function updateProductByApi($row)
	{
		/* Gán dữ liệu đồng bộ */
		$arr = array();
		$id_kioviet = $row['id_kiotviet'];
		$arr['categoryId'] = $row['id_category'];
		$arr['allowsSale'] = 1;
		$arr['conversionValue'] = 0;
		$arr['type'] = 2;

		/* Gán thuộc tính dữ liệu đồng bộ */
		$arr['inventories'] = array(
			"branchId" => $row['id_branch'],
			"branchName" => $row['ten_branch'],
			"onHand" => $row['soluong']
		);

		/* Đồng bộ dữ liệu */
		$rs = $this->init("/products/$id_kioviet", $arr, "PUT");
	}

	function checkCategoryIssetWeb($rs)
	{
		/* Gán dữ liệu */
		$data = array();
		$data['id_category'] = (int)$rs->categoryId;
		$data['tenvi'] = htmlspecialchars($rs->categoryName);
		$data['tenkhongdauvi'] = $this->changeTitlehere(htmlspecialchars($rs->categoryName));
		$data['ngaytao'] = ($rs->createdDate != '') ? strtotime($rs->createdDate) : '';
		$data['ngaysua'] = ($rs->modifiedDate != '') ? strtotime($rs->modifiedDate) : '';
		$data['hienthi'] = 1;
		$data['type'] = 'nhom-hang';

		/* Thêm - Cập nhật dữ liệu */
		$id_category = (int)$rs->categoryId;
		$checkrowproductcategory = $this->db->rawQuery("select id from #_product where id_category = ? and type= ? ", array($id_category, 'nhom-hang'));
		//die('here ok');
		if (count($checkrowproductcategory)) {
			/* Cập nhật dữ liệu */
			$row = $this->db->fetch_array();
			$id = $row['id'];
			// $this->db->setTable("product");
			// $this->db->setWhere("id", $id);
			// $this->db->update($data);

			$this->db->where('id', $id);
			$this->db->update('product', $data);
			return false;
		} else {
			/* Thêm dữ liệu */
			// $this->db->setTable("product");
			// $this->db->insert($data);
			$this->db->insert('product', $data);
			return true;
		}
	}
	function utf8converthere($str = '')
	{
		if ($str != '') {
			$utf8 = array(
				'a' => 'á|à|ả|ã|ạ|ă|ắ|ặ|ằ|ẳ|ẵ|â|ấ|ầ|ẩ|ẫ|ậ|Á|À|Ả|Ã|Ạ|Ă|Ắ|Ặ|Ằ|Ẳ|Ẵ|Â|Ấ|Ầ|Ẩ|Ẫ|Ậ',
				'd' => 'đ|Đ',
				'e' => 'é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ|É|È|Ẻ|Ẽ|Ẹ|Ê|Ế|Ề|Ể|Ễ|Ệ',
				'i' => 'í|ì|ỉ|ĩ|ị|Í|Ì|Ỉ|Ĩ|Ị',
				'o' => 'ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ|Ó|Ò|Ỏ|Õ|Ọ|Ô|Ố|Ồ|Ổ|Ỗ|Ộ|Ơ|Ớ|Ờ|Ở|Ỡ|Ợ',
				'u' => 'ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự|Ú|Ù|Ủ|Ũ|Ụ|Ư|Ứ|Ừ|Ử|Ữ|Ự',
				'y' => 'ý|ỳ|ỷ|ỹ|ỵ|Ý|Ỳ|Ỷ|Ỹ|Ỵ',
				'' => '`|\~|\!|\@|\#|\||\$|\%|\^|\&|\*|\(|\)|\+|\=|\,|\.|\/|\?|\>|\<|\'|\"|\“|\”|\:|\;|_',
			);

			foreach ($utf8 as $ascii => $uni) {
				$str = preg_replace("/($uni)/i", $ascii, $str);
			}
		}

		return $str;
	}

	/* Change title */
	function changeTitlehere($text = '')
	{
		if ($text != '') {
			$text = strtolower($this->utf8converthere($text));
			$text = preg_replace("/[^a-z0-9-\s]/", "", $text);
			$text = preg_replace('/([\s]+)/', '-', $text);
			$text = str_replace(array('%20', ' '), '-', $text);
			$text = preg_replace("/\-\-\-\-\-/", "-", $text);
			$text = preg_replace("/\-\-\-\-/", "-", $text);
			$text = preg_replace("/\-\-\-/", "-", $text);
			$text = preg_replace("/\-\-/", "-", $text);
			$text = '@' . $text . '@';
			$text = preg_replace('/\@\-|\-\@|\@/', '', $text);
		}

		return $text;
	}
	function checkProductIssetWeb($rs, $type)
	{
		/* Gán dữ liệu */
		$data = array();
		$data['id_kiotviet'] = (int)$rs->id;
		$data['id_category'] = (int)$rs->categoryId;
		$data['tenvi'] = htmlspecialchars($rs->name);
		$data['tenkhongdauvi'] = $this->changeTitlehere(htmlspecialchars($rs->name));

		// $data['motavi'] = htmlspecialchars($rs->description);
		// $data['photo'] = htmlspecialchars($rs->images);
		$data['masp'] = htmlspecialchars($rs->code);
		$data['gia'] = $rs->basePrice;
		$data['ngaytao'] = ($rs->createdDate != '') ? strtotime($rs->createdDate) : '';
		$data['ngaysua'] = ($rs->modifiedDate != '') ? strtotime($rs->modifiedDate) : '';
		$data['hienthi'] = 1;
		$data['type'] = $type;
		/* Lấy Inventories */
		$inventories = $rs->inventories;
		foreach ($inventories as $k => $v) {
			$data['soluong'] = $v->onHand;
			$data['id_branch'] = $v->branchId;
			$data['ten_branch'] = $v->branchName;
		}

		/* Thêm - Cập nhật dữ liệu */
		$masp = $rs->code;
		// $this->db->reset();
		// $this->db->query("SELECT id FROM table_product WHERE masp='$masp'");
		$checkrowproduct = $this->db->rawQuery("select id from #_product where masp = ? ", array($masp));

		if (count($checkrowproduct)) {
			/* Cập nhật dữ liệu */
			// $row = $this->db->fetch_array();
			$id = $checkrowproduct[0]['id'];
			// $this->db->setTable("product");
			// $this->db->setWhere("id", $id);
			// $this->db->update($data);


			$urlImage = $rs->images[0];

			// $nameImage = 'logo-1.png';

			// if(file_put_contents( $fp, $urlImage )){
			// 	$data['photo'] = htmlspecialchars($nameImage);
			// }
			// if($this->checkValidUrl($urlImage)){

			$photo_name = rand(0, 9999) . "-" . @end(explode("/", $urlImage));

			$this->delete_filehere(UPLOAD_PRODUCT . $photo_name);
			$this->save_image($urlImage, UPLOAD_PRODUCT . $photo_name);
			$data['photo'] = htmlspecialchars($photo_name);

			// }

			$this->db->where('id', $id);
			$this->db->update('product', $data);



			//die('here ok');
			return false;
		} else {
			/* Thêm dữ liệu */
			// $this->db->setTable("product");
			// $this->db->insert($data);
			$this->db->insert('product', $data);
			return true;
		}
		//return true;
	}
	function delete_filehere($file = '')
	{
		return @unlink($file);
	}

	function checkValidUrl($url)
	{
		$regex = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
		return preg_match($regex, $url);
	}
	function save_image($inPath, $outPath)
	{ //Download images from remote server
		$in =    fopen($inPath, "rb");
		$out =   fopen($outPath, "wb");

		while ($chunk = fread($in, 8192)) {
			fwrite($out, $chunk, 8192);
		}
		fclose($in);
		fclose($out);
	}
	function file_get_contents_curl($url)
	{
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);

		$data = curl_exec($ch);
		curl_close($ch);

		return $data;
	}
	function setToken($token, $type)
	{
		@$_SESSION['kiot']['token']['code'] = $token;
		@$_SESSION['kiot']['token']['type'] = $type;
		@$_SESSION['kiot']['token']['time'] = time() + 86400;
	}

	function getToken()
	{
		if (@$_SESSION['kiot']['token']) {
			if ((@$_SESSION['kiot']['token']['time']) < time()) {
				unset($_SESSION['kiot']);
				return false;
			}
			return $_SESSION['kiot']['token'];
		}
		return false;
	}

	function check_login()
	{
		if (!$this->getToken()) {
			$this->login();
			//$this->setProductAttribute();
		}
	}


	function login()
	{
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => "https://id.kiotviet.vn/connect/token",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => "client_id=" . $this->client . "&client_secret=" . $this->secret . "&grant_type=client_credentials&scopes=PublicApi.Access",
			CURLOPT_HTTPHEADER => array(
				"cache-control: no-cache",
				"content-type: application/x-www-form-urlencoded",
				"postman-token: a4ba83a9-fcc6-4522-b3ef-4035d4725e8e"
			),
		));
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) {
			echo ("cURL Error #:" . $err);
			die("ERROR");
			return false;
		} else {
			$rs = json_decode($response, true);
			$this->setToken($rs['access_token'], $rs['token_type']);
			return true;
		}
	}

	function init($url, $data = null, $type = "POST")
	{
		$curl = curl_init();
		if (in_array(strtolower($type), array("post", "put", "delete"))) {
			$data = json_encode($data);
		} else {
			$data = "";
		}
		$this->login();
		$token = $this->getToken();

		$xheader = array(
			"cache-control: no-cache",
			"retailer:" . $this->name,
			"authorization:" . $token['type'] . " " . $token['code'],
			"content-type: application/json",
		);
		curl_setopt_array($curl, array(
			CURLOPT_URL => $this->kiotapi_link . $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POSTFIELDS => $data,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => $type,
			CURLOPT_HTTPHEADER => $xheader
		));
		$response = curl_exec($curl);

		$err = curl_error($curl);

		curl_close($curl);
		if ($err) {
			echo $err . $this->kiotapi_link . $url;
			die;
			$this->login();
			$this->init($url, $data, $type);
		} else {
			$rs = json_decode($response);
			return $rs;
		}
	}
	function magic_quote($str, $id_connect = false)
	{
		if (is_array($str)) {
			foreach ($str as $key => $val) {
				$str[$key] = escape_str($val);
			}
			return $str;
		}

		if (is_numeric($str)) {
			return $str;
		}

		if (get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}

		if (function_exists('mysql_real_escape_string') and is_resource($id_connect)) {
			return mysql_real_escape_string($str, $id_connect);
		} elseif (function_exists('mysql_escape_string')) {
			return mysql_escape_string($str);
		} else {
			return addslashes($str);
		}
	}
}
